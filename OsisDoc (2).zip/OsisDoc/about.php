<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tentang OSIS - SMKN 5 Bulukumba</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .about-container {
            max-width: 1100px;
            margin: auto;
            padding: 30px 20px;
        }

        .about-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .about-flex {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: flex-start;
            justify-content: center;
        }

        .about-img {
            max-width: 300px;
            border-radius: 12px;
            animation: minimalisir-img 5s infinite alternate ease-in-out;
        }

        .about-content {
            flex: 1;
            min-width: 260px;
        }

        .about-info ul {
            list-style: none;
            padding: 0;
            line-height: 1.8;
        }

        .about-info li {
            margin-bottom: 8px;
        }

        iframe {
            width: 100%;
            height: 350px;
            border: 0;
            border-radius: 12px;
            margin-top: 20px;
        }

        @media (max-width: 768px) {
            .about-flex {
                flex-direction: column;
                align-items: center;
            }
        }
        .card_object{
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            padding: 25px 20px;
            margin: 10px;
            transition: all 0.3s ease;
            max-width: 280px;
            border-radius: 16px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .card_object::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #3b82f6, #10b981);
        }
        .card_object:hover{
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 12px 35px rgba(59, 130, 246, 0.15);
            border-color: #3b82f6;
        }
        .card_image{
            width: 100%;
            max-width: 250px;
            height: 250px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 10px;
            border: 5px solid white;
        }
        .card_name{
            color: #1f2937;
            margin: 15px 0 12px 0;
            font-size: 1.25em;
            font-weight: 700;
            line-height: 1.3;
        }
        .card_jabatan{
            color: #6b7280;
            margin-bottom: 0;
            font-size: 0.95em;
            font-weight: 600;
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
            padding: 8px 12px;
            border-radius: 20px;
            display: inline-block;
            border: 1px solid #cbd5e1;
        }
        
        .card-x{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }
        .card-x-a{
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
        }
        .about-flex{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        @media (max-width: 768px) {
            .card_object {
                max-width: 100%;
                margin: 10px 5px;
            }
        }

        @keyframes minimalisir-img {
            0% {
                transform: scale(1);
            }
            100% {
                transform: scale(1.05);
            }
        }
    </style>
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="about-container">
    <div style="margin-top:10vh" class="about-header">
        <h1>Tentang OSIS SMKN 5 Bulukumba</h1>
    </div>

    <div class="about-flex">
        <img src="media/profile-osis.jpg" alt="Profil OSIS" class="about-img">
        <div class="about-content">
            <p>
                OSIS SMKN 5 Bulukumba adalah organisasi siswa yang berperan penting dalam membangun karakter, kepemimpinan,
                dan kreativitas siswa. Kami menyelenggarakan berbagai kegiatan kesiswaan, seperti lomba, seminar, dan kegiatan sosial.
            </p>
            <p>
                Visi kami adalah menjadikan OSIS sebagai pelopor kegiatan positif dan inovatif yang mendukung visi sekolah.
            </p>
        </div>
    </div>

    <hr style="margin: 40px 0; border-color: #ddd;">

    <h1 style='text-align: center;'>🔥 PENGURUS INTI 🔥</h1>
    <div class="about-flex">
        <div class="card-x">
        </div>
    </div>

    <br>
    <h1 style='text-align: center;'>STRUKTUR ORGANISASI SEKSI BIDANG (SEKBID)</h1>
    <p style="text-align: center; margin-bottom: 30px; color: #6b7280;">
        OSIS SMKN 5 Bulukumba terdiri dari 8 Seksi Bidang sesuai dengan program kerja organisasi
    </p>
    <div class="about-flex">
        <div class="card-x-a">
        </div>
    </div>
    
        <hr style="margin: 40px 0; border-color: #ddd;">

    <div class="about-info">
        <h2>Informasi Sekolah</h2>
        <ul>
            <li><strong>Nama:</strong> SMK Negeri 5 Bulukumba</li>
            <li><strong>Alamat:</strong> Jl. Poros Sampeang, Bontoharu, Kec. Rilau Ale, Kabupaten Bulukumba, Sulawesi Selatan 92552</li>
            <li><strong>Lokasi Map:</strong> J655+GM9 SMK Negeri 5 Bulukumba</li>
            <li><strong>Email:</strong> osis@smkn5bulukumba.sch.id</li>
            
        </ul>
    </div>

    <h2>Lokasi di Google Maps</h2>
    <div style="position: relative;"><div style="position: relative; padding-bottom: 75%; height: 0; overflow: hidden;"><iframe style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border:0;" loading="lazy" allowfullscreen src="https://maps.google.com/maps?q=smkn+negeri+5+bulukumba&output=embed"></iframe></div><a href="https://contentgoblin.ai/ai-pinterest-pin-generator/" rel="noopener" target="_blank" style="position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0;">Powered By Vtech Ai</a></div>
</div>

<?php include 'includes/footer.php'; ?>
<script src="assets/js/card.js"></script>
</body>
</html>