<?php
$programs = json_decode(file_get_contents('data/programs.json'), true);

// Fungsi sederhana Markdown to HTML
function markdownToHtml($text) {
    $text = htmlspecialchars($text);
    $text = preg_replace('/\r\n|\r|\n/', "<br>", $text);
    $text = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $text);
    $text = preg_replace('/- (.*?)(<br>|$)/', '<li>$1</li>', $text);
    $text = preg_replace('/(<li>.*<\/li>)/s', '<ul>$1</ul>', $text);
    return $text;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Proker - OSIS SMKN 5 Bulukumba</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: #f0f4f8;
            color: #333;
        }
        header {
            background: linear-gradient(135deg, #3b82f6, #10b981);
            color: white;
            padding: 20px 40px;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 1.8em;
        }
        .back-btn {
            margin-top: 10px;
            display: inline-block;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            padding: 8px 16px;
            border-radius: 25px;
            text-decoration: none;
            transition: 0.3s;
            font-size: 0.9em;
        }
        .back-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        .container {
            max-width: 960px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .proker-card {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 6px 12px rgba(0,0,0,0.05);
            transition: 0.3s ease;
        }
        .proker-card:hover {
            transform: translateY(-3px);
        }
        .proker-title {
            font-size: 1.3em;
            font-weight: 600;
            margin-bottom: 10px;
            color: #1f2937;
        }
        .proker-description {
            white-space: pre-line;
            color: #4b5563;
            margin-bottom: 12px;
        }
        .proker-meta {
            font-size: 0.9em;
            color: #6b7280;
        }
        .status {
            display: inline-block;
            padding: 4px 10px;
            font-size: 0.75em;
            border-radius: 20px;
            background-color: #dbeafe;
            color: #1d4ed8;
            text-transform: capitalize;
        }
        footer {
            text-align: center;
            padding: 20px;
            font-size: 0.85em;
            color: #94a3b8;
        }
    </style>
</head>
<body>

    <header>
        <h1><i class="fas fa-tasks"></i> Program Kerja OSIS</h1>
        <a href="javascript:history.back()" class="back-btn">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </header>

    <div class="container">
        <?php if ($programs): ?>
            <?php foreach ($programs as $proker): ?>
                <div class="proker-card">
                    <div class="proker-title">
                        <i class="fas fa-check-circle"></i> <?= htmlspecialchars($proker['name']) ?>
                    </div>

                    <?php if (!empty($proker['photo'])): ?>
                        <img src="<?= htmlspecialchars($proker['photo']) ?>" alt="Gambar Proker" style="width: 100%; max-height: 300px; object-fit: cover; border-radius: 10px; margin-bottom: 15px;">
                    <?php endif; ?>

                    <div class="proker-description">
                        <?= markdownToHtml($proker['description']) ?>
                    </div>
                    <div class="proker-meta">
                        <i class="fas fa-calendar-alt"></i> <?= $proker['startDate'] ?> s/d <?= $proker['endDate'] ?><br>
                        <i class="fas fa-signal"></i> Status: <span class="status"><?= $proker['status'] ?></span><br>
                        <i class="fas fa-clock"></i> Dibuat: <?= $proker['createdAt'] ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Tidak ada data proker ditemukan.</p>
        <?php endif; ?>
    </div>

    <footer>
        &copy; <?= date('Y') ?> OSIS SMKN 5 Bulukumba
    </footer>

</body>
</html>