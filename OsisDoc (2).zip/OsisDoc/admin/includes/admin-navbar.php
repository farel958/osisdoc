<nav class="navbar">
    <div class="container">
        <div class="navbar-brand">
            <a href="../index.php">OSIS SMKN 5 Bulukumba</a>
        </div>
        
        <div class="navbar-menu">
            <div class="navbar-nav">
                <a href="../index.php" class="nav-link">
                    <i class="fas fa-home"></i>
                    Beranda
                </a>
                <a href="../koleksi.php" class="nav-link">
                    <i class="fas fa-images"></i>
                    Koleksi
                </a>
                <a href="dashboard.php" class="nav-link active">
                    <i class="fas fa-tachometer-alt"></i>
                    Dashboard
                </a>
                <a href="logout.php" class="nav-link" style="color: var(--danger-color);">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </div>
    </div>
</nav>