<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3>OSIS SMKN 5 Bulukumba</h3>
                <p>Organisasi Siswa Intra Sekolah yang berkomitmen untuk mengembangkan potensi siswa.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="index.php">Beranda</a></li>
                    <li><a href="koleksi.php">Koleksi</a></li>
                    <li><a href="proker.php">Proker</a></li>
                    <li><a href="admin/login.php">Admin</a></li>
                    <li><a href="about.php">About</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Kontak</h4>
                <p><i class="fas fa-map-marker-alt"></i> SMKN 5 Bulukumba</p>
                <p><i class="fas fa-envelope"></i> osis@smkn5bulukumba.sch.id</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> OSIS SMKN 5 Bulukumba. All rights reserved.</p>
        </div>
    </div>
</footer>