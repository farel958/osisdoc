<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Get search parameters
$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$type = $_GET['type'] ?? '';

// Get filtered media
$media = searchMedia($search, $category, $type);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Koleksi Dokumentasi - OSIS SMKN 5 Bulukumba</title>
    <meta name="description" content="Jelajahi koleksi foto dan video kegiatan OSIS SMKN 5 Bulukumba. Dokumentasi lengkap program kerja dan event sekolah.">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .doc-image img {
            width: 100%;
            height: 250px; /* Increased height for better image display */
            object-fit: cover; /* Ensure images fill the container while maintaining aspect ratio */
        }

        /* Ensure proper aspect ratio for mobile */
        @media (max-width: 768px) {
            .doc-image img {
                height: 220px;
            }
        }

        @media (max-width: 480px) {
            .doc-image img {
                height: 200px;
            }
        }

        /* Image Modal Styles */
        .image-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
            z-index: 1000;
        }

        .image-modal.active {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            position: relative;
            max-width: 90%;
            max-height: 100%;
        }

        .modal-image {
            max-width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(0, 0, 0, 0.5);
            color: #fff;
            border: none;
            padding: 10px 15px;
            font-size: 20px;
            cursor: pointer;
            z-index: 1001;
        }
    </style>
</head>
<body>
    <?php include 'includes/navbar.php'; ?>

    <!-- Collection Header -->
    <section class="collection-header">
        <div class="container">
            <h1>Koleksi Dokumentasi</h1>
            <p>Jelajahi foto dan video kegiatan OSIS SMKN 5 Bulukumba</p>
        </div>
    </section>

    <!-- Collection Content -->
    <section class="collection-content">
        <div class="container">
            <!-- Search and Filters -->
            <div class="search-filters">
                <form method="GET" action="">
                    <div class="filter-row">
                        <div class="filter-group">
                            <label for="search">Cari Dokumentasi</label>
                            <div class="search-input">
                                <i class="fas fa-search"></i>
                                <input type="text" id="search" name="search" class="form-control" 
                                       placeholder="Cari berdasarkan judul atau deskripsi..." 
                                       value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                        </div>

                        <div class="filter-group">
                            <label for="type">Tipe Media</label>
                            <select id="type" name="type" class="form-control">
                                <option value="">Semua Tipe</option>
                                <option value="image" <?php echo $type === 'image' ? 'selected' : ''; ?>>Foto</option>
                                <option value="video" <?php echo $type === 'video' ? 'selected' : ''; ?>>Video</option>
                            </select>
                        </div>

                        <div class="filter-group">
                            <label for="category">Kategori</label>
                            <select id="category" name="category" class="form-control">
                                <option value="">Semua Kategori</option>
                                <option value="kegiatan-sekolah" <?php echo $category === 'kegiatan-sekolah' ? 'selected' : ''; ?>>Kegiatan Sekolah</option>
                                <option value="program-kerja" <?php echo $category === 'program-kerja' ? 'selected' : ''; ?>>Program Kerja</option>
                                <option value="event-khusus" <?php echo $category === 'event-khusus' ? 'selected' : ''; ?>>Event Khusus</option>
                                <option value="lainnya" <?php echo $category === 'lainnya' ? 'selected' : ''; ?>>Lainnya</option>
                            </select>
                        </div>

                        <div class="filter-group">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> Cari
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Media Grid -->
            <?php if (!empty($media)): ?>
                <div class="docs-grid">
                    <?php foreach ($media as $item): ?>
                        <div class="doc-card">
                            <div class="doc-image">
                                <?php if (strpos($item['mimeType'], 'image/') === 0): ?>
                                    <img src="uploads/<?php echo htmlspecialchars($item['filename']); ?>" 
                                         alt="<?php echo htmlspecialchars($item['title']); ?>"
                                         loading="lazy">
                                    <div class="doc-overlay">
                                        <a href="#" onclick="openImageModal('uploads/<?php echo htmlspecialchars($item['filename']); ?>', '<?php echo htmlspecialchars($item['title']); ?>')"
                                           class="btn btn-sm btn-secondary">
                                            <i class="fas fa-eye"></i> Lihat
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <div class="video-placeholder">
                                        <i class="fas fa-play"></i>
                                        <p>Video</p>
                                        <div class="doc-overlay">
                                            <a href="uploads/<?php echo htmlspecialchars($item['filename']); ?>" 
                                               target="_blank" class="btn btn-sm btn-secondary">
                                                <i class="fas fa-play"></i> Putar
                                            </a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="doc-content">
                                <h3><?php echo htmlspecialchars($item['title']); ?></h3>
                                <p><?php echo htmlspecialchars($item['description'] ?: 'Tidak ada deskripsi'); ?></p>
                                <div class="doc-meta">
                                    <span class="status-badge status-secondary">
                                        <?php echo getCategoryLabel($item['category']); ?>
                                    </span>
                                    <span class="file-size"><?php echo formatFileSize($item['size']); ?></span>
                                </div>
                                <div class="doc-date">
                                    <i class="fas fa-calendar"></i>
                                    <?php echo formatDate($item['uploadedAt']); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <!-- Empty State -->
                <div class="empty-state">
                    <?php if ($search || $category || $type): ?>
                        <i class="fas fa-search"></i>
                        <h3>Tidak Ada Hasil Ditemukan</h3>
                        <p>Coba ubah kata kunci pencarian atau filter untuk mendapatkan hasil yang berbeda.</p>
                        <a href="koleksi.php" class="btn btn-primary">Reset Filter</a>
                    <?php else: ?>
                        <i class="fas fa-images"></i>
                        <h3>Belum Ada Dokumentasi</h3>
                        <p>Koleksi dokumentasi masih kosong. Admin dapat menambahkan foto dan video melalui panel admin.</p>
                        <a href="admin/login.php" class="btn btn-primary">Login Admin</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Image Modal -->
    <div id="imageModal" class="image-modal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeImageModal()">&times;</button>
            <img id="modalImage" class="modal-image" src="" alt="">
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/script.js"></script>
    <script>
        function openImageModal(imageSrc, imageTitle) {
            const modal = document.getElementById('imageModal');
            const modalImage = document.getElementById('modalImage');

            modalImage.src = imageSrc;
            modalImage.alt = imageTitle;
            modal.classList.add('active');

            // Prevent body scroll
            document.body.style.overflow = 'hidden';
        }

        function closeImageModal() {
            const modal = document.getElementById('imageModal');
            modal.classList.remove('active');

            // Restore body scroll
            document.body.style.overflow = 'auto';
        }

        // Close modal when clicking outside the image
        document.getElementById('imageModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeImageModal();
            }
        });

        // Close modal with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeImageModal();
            }
        });
    </script>
</body>
</html>