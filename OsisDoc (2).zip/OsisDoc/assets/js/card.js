
function $(query) {
  return document.querySelector(query);
}

// PENGURUS INTI
let aCard = [
  {
    "nama_pengurus": "Dina Afrilianti",
    "jabatan": "Ketua Osis",
    "instagram": "dina.marlina"
  },
  {
    "nama_pengurus": "Nursyafika",
    "jabatan": "Wakil Ketua",
    "instagram": "ahmad.fadli"
  },
  {
    "nama_pengurus": "Hajrah",
    "jabatan": "Sekretaris",
    "instagram": "sari.dewi"
  },
  {
    "nama_pengurus": "Silfa Vinasti",
    "jabatan": "Wakil Sekertaris",
    "instagram": "budi.santoso"
  },
  {
    "nama_pengurus": "Rifda Nurhidayah",
    "jabatan": "Bendahara",
    "instagram": "budi.santoso"
  },
  {
    "nama_pengurus": "A. Reski Amalia Ramadhani",
    "jabatan": "Wakil Bendahara",
    "instagram": "budi.santoso"
  }
];

// SEKBID 1: Ketaqwaan Kepada Tuhan Yang Maha Esa
let sekbid1 = [
  {
    "nama_pengurus": "Nurfa Putri Andayani",
    "jabatan": "Anggota Sekbid 1",
    "instagram": "fatimah.zahra"
  },
  {
    "nama_pengurus": "Putri",
    "jabatan": "Anggota Sekbid 1",
    "instagram": "m.ikhsan"
  }
];

// SEKBID 2: Kehidupan Berbangsa dan Bernegara
let sekbid2 = [
  {
    "nama_pengurus": "Syaepul",
    "jabatan": "Anggota Sekbid 2",
    "instagram": "rizky.pratama"
  },
  {
    "nama_pengurus": "Aliya",
    "jabatan": "Anggota Sekbid 2",
    "instagram": "indira.sari"
  },
  {
    "nama_pengurus": "Afdal Abrar",
    "jabatan": "Anggota Sekbid 2",
    "instagram": "bayu.wijaya"
  }
];

// SEKBID 3: Pendidikan Pendahuluan Bela Negara
let sekbid3 = [
  {
    "nama_pengurus": "Celsi",
    "jabatan": "Anggota Sekbid 3",
    "instagram": "deva.mahardika"
  },
  {
    "nama_pengurus": "Sahrir",
    "jabatan": "Anggota Sekbid 3",
    "instagram": "luna.aprilia"
  },
  {
    "nama_pengurus": "Naila Thulmaira",
    "jabatan": "Anggota Sekbid 3",
    "instagram": "arif.budiman"
  }
];

// SEKBID 4: Kepribadian dan Budi Pekerti Luhur
let sekbid4 = [
  {
    "nama_pengurus": "Riska Febriani",
    "jabatan": "Anggota Sekbid 4",
    "instagram": "maya.safitri"
  },
  {
    "nama_pengurus": "Muhammad Shiddiq",
    "jabatan": "Anggota Sekbid 4",
    "instagram": "farel.ahmad"
  }
];

// SEKBID 5: Berorganisasi, Pendidikan Politik dan Kepemimpinan
let sekbid5 = [
  {
    "nama_pengurus": "Faaza Alfi Rahmaniya",
    "jabatan": "Anggota Sekbid 5",
    "instagram": "kevin.pratama"
  },
  {
    "nama_pengurus": "Eharini",
    "jabatan": "Anggota Sekbid 5",
    "instagram": "galang.surya"
  }
];

// SEKBID 6: Keterampilan dan Kewirausahaan
let sekbid6 = [
  {
    "nama_pengurus": "Dini Andriani",
    "jabatan": "Anggota Sekbid 6",
    "instagram": "anisa.fitri"
  },
  {
    "nama_pengurus": "A. wannas",
    "jabatan": "Anggota Sekbid 6",
    "instagram": "yoga.permana"
  },
  {
    "nama_pengurus": "Nisa",
    "jabatan": "Anggota Sekbid 6",
    "instagram": "diah.kusuma"
  },
  {
    "nama_pengurus": "Ananda Salsabilah Ilyas",
    "jabatan": "Anggota Sekbid 6",
    "instagram": "diah.kusuma"
  }
];

// SEKBID 7: Kesegaran Jasmani dan Daya Kreasi
let sekbid7 = [
  {
    "nama_pengurus": "Reski Muhammad",
    "jabatan": "Anggota Sekbid 7",
    "instagram": "hendra.saputra"
  },
  {
    "nama_pengurus": "Nurhayani",
    "jabatan": "Anggota Sekbid 7",
    "instagram": "riska.amelia"
  }
];

// SEKBID 8: Persepsi, Apresiasi dan Kreasi Seni
let sekbid8 = [
  {
    "nama_pengurus": "Rahmawati",
    "jabatan": "Anggota Sekbid 8",
    "instagram": "citra.melati"
  },
  {
    "nama_pengurus": "Asninda",
    "jabatan": "Anggota Sekbid 8",
    "instagram": "fauzi.rahman"
  },
  {
    "nama_pengurus": "Farel Alfareza",
    "jabatan": "Anggota Sekbid 8",
    "instagram": "lita.sari"
  }
];

// Function to create card
function createCard(card) {
  let card_object = document.createElement('div');
  card_object.className = 'card_object';

  let card_name = document.createElement('h3');
  card_name.className = 'card_name';
  card_name.innerText = card.nama_pengurus;

  let card_jabatan = document.createElement('p');
  card_jabatan.className = 'card_jabatan';
  card_jabatan.innerText = card.jabatan;

  card_object.append(card_name, card_jabatan);
  return card_object;
}

// Render Pengurus Inti
const cardContainer = $('.card-x');
if (cardContainer) {
  aCard.forEach((card) => {
    cardContainer.append(createCard(card));
  });
}

// Render all Sekbid
const sekbidContainer = $('.card-x-a');
if (sekbidContainer) {
  const allSekbid = [
    { title: "🤲 SEKBID 1 🤲\nKetakwaan Terhadap Tuhan Yang Maha Esa", members: sekbid1 },
    { title: "🏛️ SEKBID 2 🏛️\nKehidupan Berbangsa dan Bernegara", members: sekbid2 },
    { title: "🛡️ SEKBID 3 🛡️\nPendidikan Pendahuluan Bela Negara", members: sekbid3 },
    { title: "📚 SEKBID 4 📚\nKepribadian dan Budi Pekerti Luhur", members: sekbid4 },
    { title: "👑 SEKBID 5 👑\nBerorganisasi, Pendidikan Politik dan Kepemimpinan", members: sekbid5 },
    { title: "💼 SEKBID 6 💼\nKeterampilan dan Kewirausahaan", members: sekbid6 },
    { title: "⚽ SEKBID 7 ⚽\nKesegaran Jasmani dan Daya Kreasi", members: sekbid7 },
    { title: "🎨 SEKBID 8 🎨\nTIK (Teknologi Informasi Dan Komunikasi)", members: sekbid8 }
  ];

  allSekbid.forEach((sekbid) => {
    // Create section title
    let sectionTitle = document.createElement('h3');
    sectionTitle.style.cssText = `
      width: 100%;
      text-align: center;
      margin: 30px 0 20px 0;
      color: #1f2937;
      font-size: 1.2em;
      border-bottom: 2px solid #3b82f6;
      padding-bottom: 10px;
      white-space: pre-line;
    `;
    sectionTitle.innerText = sekbid.title;
    sekbidContainer.append(sectionTitle);

    // Create cards container for this sekbid
    let sekbidCards = document.createElement('div');
    sekbidCards.style.cssText = `
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
      margin-bottom: 40px;
      width: 100%;
    `;

    sekbid.members.forEach((member) => {
      sekbidCards.append(createCard(member));
    });

    sekbidContainer.append(sekbidCards);
  });
}
